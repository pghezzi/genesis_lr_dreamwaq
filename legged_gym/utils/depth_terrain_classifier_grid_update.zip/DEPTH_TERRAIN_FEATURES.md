# Depth-Terrain Feature Extraction Reference

This document describes the 54 scalar features produced by
`SobelDepthTerrainFeatureExtractor` in `depth_terrain_classifier.py`.

The feature extractor accepts a depth image together with robot roll, pitch, and body
angular velocity. It does not construct a point cloud. The original 30 features are
retained in their original order, and 24 spatial grid features are appended.

## 1. Image preprocessing and notation

For the expected 48 x 64 input image, the default fractional crop removes the upper
10% and the outer 5% of each side. The retained crop is then resized to the extractor's
default internal resolution of 32 x 48. All features below are computed on this retained
and resized image.

Let:

- `D(u,v)` be the filled, cropped, and resized depth image.
- `V(u,v) in {0,1}` be the corresponding valid-depth mask.
- `D_hat(u,v; phi, theta)` be the expected flat-ground depth conditioned on roll `phi`
  and pitch `theta`.
- `R = D - D_hat` be the orientation-conditioned residual-depth image.
- `s_D` be `depth_scale`, normally `max_depth - min_depth`.
- `G_sigma` be the normalized 3 x 3 Gaussian kernel.
- `S_x` and `S_y` be normalized 3 x 3 Sobel kernels.
- `G_x = S_x * (G_sigma * R)` and `G_y = S_y * (G_sigma * R)`.
- `G = sqrt(G_x^2 + G_y^2 + epsilon)` be Sobel magnitude.
- `L = K_L * (G_sigma * R)` be the discrete Laplacian response.
- `A_k(R)` be a stride-one `k x k` local average of `R`.
- `H_3 = |R - A_3(R)|` and `H_7 = |R - A_7(R)|` be fine and coarse
  high-pass residuals.
- `M_A(X)` denote the mean of `X` over region `A`, using only valid pixels when a
  validity mask is specified.
- `Q_q(X)` denote the `q` quantile over valid pixels.
- `Top_q(X)` denote the mean of the largest fraction `q` of valid values.

A 3 x 3 valid neighborhood mask is used for derivative statistics so that Sobel and
Laplacian values adjacent to invalid measurements do not contaminate ordinary terrain
edge measurements. Missing-depth structure is instead represented explicitly by the
occupancy and invalid-boundary features.

## 2. Global regions of interest

The retained 32 x 48 image uses several overlapping regions:

- **Near region `N`:** bottom 35% of rows, full width.
- **Far region `F`:** top one-third of rows, full width.
- **Center corridor `C`:** center 50% of columns, full height.
- **Upper-center region `U`:** top 40% of rows intersected with the center corridor.

Most original features use the entire retained image. These regions add a small amount
of targeted spatial information for near-ground roughness, broad near/far layout, and
overhead obstacles.

## 3. Original 30 features

### 3.1 Depth support, free space, and obstacle occupancy

1. **`valid_fraction`**

   Fraction of retained pixels with valid depth:

   `f_valid = mean(V)`.

   Low values can indicate missing returns, open space, sensor limitations, or a gap.

2. **`far_or_invalid_fraction`**

   `f_far = mean(1[D >= d_far OR V = 0])`.

   Captures distant/open space and missing support, especially useful for gaps.

3. **`invalid_boundary_density`**

   Sobel magnitude is computed on a Gaussian-smoothed validity mask. The feature is
   the fraction of pixels whose validity-edge magnitude exceeds 0.10:

   `f_invalid_edge = mean(1[sqrt(GV_x^2 + GV_y^2 + epsilon) > 0.10])`.

   This distinguishes structured missing-depth boundaries from uniformly poor sensing.

4. **`depth_iqr`**

   `f_IQR = (Q_0.75(D) - Q_0.25(D)) / s_D`.

   A robust measure of overall depth spread.

5. **`near_far_depth_delta`**

   `f_NF = (M_N(D) - M_F(D)) / s_D`.

   Captures broad longitudinal scene layout, such as a nearby wall, pit exit, ramp,
   or open gap.

6. **`upper_center_close_fraction`**

   Define a close-return mask:

   `C_close = V AND (D < d_close OR R < -delta_close)`.

   Then:

   `f_Uclose = mean_U(C_close)`.

   Sensitive to low ceilings and obstacles that may require crawling underneath.

7. **`center_close_fraction`**

   `f_Cclose = mean_C(C_close)`.

   Detects close geometry in the robot's forward travel corridor.

### 3.2 Multi-scale roughness

8. **`fine_roughness`**

   `f_fine = M_valid(H_3) / s_D`.

   Captures small, distributed surface variation such as gravel, rubble, or vegetation.

9. **`near_fine_roughness`**

   `f_near_fine = M_N,valid(H_3) / s_D`.

   Emphasizes small-scale roughness near the robot's upcoming footholds.

10. **`coarse_roughness`**

    `f_coarse = M_valid(H_7) / s_D`.

    Responds to larger undulations, ledges, stair structure, and broader unevenness.

11. **`roughness_scale_ratio`**

    `f_ratio = f_fine / max(f_coarse, epsilon)`.

    Indicates whether surface variation is dominated by fine texture or larger-scale
    structure.

### 3.3 Sobel edge and organized ledge features

12. **`sobel_magnitude_mean`**

    `f_Gmean = M_valid-neighborhood(G) / s_D`.

    Average orientation-independent edge strength.

13. **`sobel_magnitude_p90`**

    `f_G90 = Q_0.90(G) / s_D` over valid neighborhoods.

    Represents strong but not necessarily widespread boundaries.

14. **`horizontal_edge_energy`**

    `f_H = M_valid-neighborhood(|G_y|) / s_D`.

    Strong for horizontal image structures such as stair risers, pit lips, and gap lips.

15. **`vertical_edge_energy`**

    `f_V = M_valid-neighborhood(|G_x|) / s_D`.

    Captures side walls, obstacle sides, and left-right scene boundaries.

16. **`horizontal_edge_density`**

    `f_Hdensity = count(|G_y| > tau_edge AND valid-neighborhood) / count(valid-neighborhood)`.

    Measures how spatially widespread strong horizontal transitions are.

17. **`horizontal_edge_topk`**

    `f_Htop = Top_q(|G_y|) / s_D`, with `q = topk_fraction`.

    Preserves isolated strong ledges that a global mean could dilute.

18. **`row_edge_repetition`**

    First compute the mean horizontal-edge strength for each image row:

    `e(v) = M_width,valid-neighborhood(|G_y(u,v)|)`.

    Then:

    `f_repeat = mean_v(1[e(v) > tau_edge])`.

    Several strong rows are characteristic of repeated stair risers; a single gap or
    pit lip usually activates fewer rows.

19. **`strongest_row_edge`**

    `f_rowmax = max_v e(v) / s_D`.

    Measures the strength of the most prominent horizontally extended boundary.

20. **`horizontal_edge_dominance`**

    `f_dom = f_H / max(f_V, epsilon)`.

    Distinguishes predominantly horizontal terracing from vertical side boundaries.

21. **`positive_row_transition`**

    `f_pos = Top_q(max(G_y, 0)) / s_D`.

    Retains one direction of signed row transition.

22. **`negative_row_transition`**

    `f_neg = Top_q(max(-G_y, 0)) / s_D`.

    Retains the opposite transition direction. The pair helps separate upward and
    downward geometry that has similar absolute edge strength.

### 3.4 Curvature and row-profile structure

23. **`laplacian_abs_mean`**

    `f_Lmean = M_valid-neighborhood(|L|) / s_D`.

    Measures average local curvature and high-frequency surface structure.

24. **`laplacian_p90`**

    `f_L90 = Q_0.90(|L|) / s_D` over valid neighborhoods.

    Captures strong localized curvature.

25. **`row_profile_curvature`**

    Define the row-mean residual profile:

    `p(v) = M_width,valid(R(u,v))`.

    The feature is the mean absolute second difference:

    `f_rowcurv = mean_v |p(v+1) - 2 p(v) + p(v-1)| / s_D`.

    Sensitive to repeated terracing and broad concave or convex depth layouts.

### 3.5 IMU context

26. **`imu_roll`**

    `f_roll = phi / s_orientation`.

27. **`imu_pitch`**

    `f_pitch = theta / s_orientation`.

28. **`imu_omega_x`**

    `f_omega_x = omega_x / s_omega`.

29. **`imu_omega_y`**

    `f_omega_y = omega_y / s_omega`.

30. **`imu_omega_z`**

    `f_omega_z = omega_z / s_omega`.

Roll and pitch are also used to construct the expected flat-ground image. They are
retained as explicit features because the compensation is approximate and terrain
classes can occur in systematically different body configurations. Angular velocity
provides context for rapid camera/robot motion, such as leaping or pitching during a
pit exit.

## 4. Added 2 x 3 spatial grid

The retained image is divided into six non-overlapping patches:

| Patch | Row range | Column range at 32 x 48 |
|---|---:|---:|
| top-left | top half | 0-15 |
| top-center | top half | 16-31 |
| top-right | top half | 32-47 |
| bottom-left | bottom half | 0-15 |
| bottom-center | bottom half | 16-31 |
| bottom-right | bottom half | 32-47 |

At the default 32 x 48 internal resolution, each patch is 16 x 16. More generally, the
integer boundaries are `[0, H//2, H]` and `[0, W//3, 2W//3, W]`, so every retained pixel
belongs to exactly one patch even when dimensions are not evenly divisible.

For each patch `P`, four features are appended in this order:

1. **Mean residual depth**

   `f_P,residual = M_P,valid(R) / s_D`.

   This signed feature indicates whether local geometry is systematically closer or
   farther than the expected flat-ground surface.

2. **Fine roughness**

   `f_P,rough = M_P,valid(H_3) / s_D`.

   Localizes gravel, rubble, uneven footholds, vegetation, or other fine structure.

3. **Mean Sobel magnitude**

   `f_P,Sobel = M_P,valid-neighborhood(G) / s_D`.

   Localizes step edges, ledges, side boundaries, obstacle edges, and overhead-obstacle
   boundaries independent of edge orientation.

4. **Far-or-invalid occupancy**

   `f_P,far = mean_P(1[D >= d_far OR V = 0])`.

   Localizes open space, missing support, and distant returns instead of averaging them
   across the complete image.

The 24 appended feature names are:

- `grid_top_left_mean_residual_depth`
- `grid_top_left_fine_roughness`
- `grid_top_left_sobel_magnitude_mean`
- `grid_top_left_far_or_invalid_fraction`
- `grid_top_center_mean_residual_depth`
- `grid_top_center_fine_roughness`
- `grid_top_center_sobel_magnitude_mean`
- `grid_top_center_far_or_invalid_fraction`
- `grid_top_right_mean_residual_depth`
- `grid_top_right_fine_roughness`
- `grid_top_right_sobel_magnitude_mean`
- `grid_top_right_far_or_invalid_fraction`
- `grid_bottom_left_mean_residual_depth`
- `grid_bottom_left_fine_roughness`
- `grid_bottom_left_sobel_magnitude_mean`
- `grid_bottom_left_far_or_invalid_fraction`
- `grid_bottom_center_mean_residual_depth`
- `grid_bottom_center_fine_roughness`
- `grid_bottom_center_sobel_magnitude_mean`
- `grid_bottom_center_far_or_invalid_fraction`
- `grid_bottom_right_mean_residual_depth`
- `grid_bottom_right_fine_roughness`
- `grid_bottom_right_sobel_magnitude_mean`
- `grid_bottom_right_far_or_invalid_fraction`

## 5. Total dimensionality

The feature vector contains:

- 30 retained global/region/IMU features, and
- 6 patches x 4 features per patch = 24 spatial features.

Therefore:

`feature_dim = 30 + 24 = 54`.

The 48 x 64 input resolution does not directly determine the feature-vector length;
each image or patch is reduced to scalar statistics. The internal crop and resize also
remain unchanged.

## 6. Intended terrain cues

- **Pseudo-flat rough terrain / gravel:** global and patch-level fine roughness,
  Laplacian statistics, and distributed Sobel energy.
- **Stairs:** horizontal-edge density, row-edge repetition, strongest row edge,
  row-profile curvature, and the spatial distribution of patch Sobel responses.
- **Pit exit:** signed mean residuals, near/far depth layout, strong localized row edges,
  pitch/angular-velocity context, and bottom-center patch geometry.
- **Gap:** global and patch-level far-or-invalid occupancy, invalid-boundary density,
  and a localized strong lip edge.
- **Crawl-under obstacle:** upper-center and center close occupancy, plus top-center or
  top-side patch residual and Sobel responses.
- **Future asymmetric terrain:** the left/center/right patch features preserve offset
  gaps, partial obstacles, diagonal structure, and one-sided roughness that global
  statistics can average away.
