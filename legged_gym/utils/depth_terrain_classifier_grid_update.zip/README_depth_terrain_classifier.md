# Incremental Depth-Terrain Classifier

`depth_terrain_classifier.py` implements a lightweight terrain classifier for a quadruped using a depth image, IMU orientation, and IMU angular velocity. It is intended for small labeled datasets and approximately 10 Hz deployment.

The pipeline is:

```text
depth + roll/pitch + angular velocity
    -> orientation-conditioned depth residual
    -> Sobel/Laplacian/occupancy features
    -> standardization + PCA
    -> one or more prototypes per class
    -> optional temporal probability filtering
```

Only PyTorch is required. The classifier does not create a point cloud and does not use an explicit unknown class.

## Main classes

- `SobelDepthTerrainFeatureExtractor`: extracts 54 compact scalar features, including a 2 x 3 spatial grid.
- `IncrementalPCAPrototypeClassifier`: standardizes features, fits PCA, and stores one or more k-means prototypes per class.
- `TemporalProbabilityFilter`: smooths probabilities with an exponential moving average and switch hysteresis.
- `DepthTerrainClassifier`: unified calibration, fitting, incremental update, experiment, inference, and save/load interface.

## Why these features

The feature set combines generic geometric cues useful for both the requested terrains and later additions:

- **Rough/gravel:** fine and coarse high-pass roughness, Sobel magnitude, and Laplacian response.
- **Stairs:** repeated horizontal Sobel edges, strong row-wise edges, row-profile curvature, and horizontal-edge dominance.
- **Pit exit:** broad near/far depth change and strong signed horizontal ledges.
- **Gap:** far or invalid occupancy and invalid-depth boundary density.
- **Crawling under an obstacle:** close returns in the upper-center and center corridor.
- **Robot motion/context:** roll, pitch, and body angular velocity. Yaw is omitted to preserve yaw invariance.

A small roll/pitch-conditioned flat-ground reference model can be calibrated to remove normal perspective and body-orientation effects without converting depth to a point cloud.

## Recommended data organization

Split training and validation by traversal or episode, not randomly by adjacent frames. Consecutive 10 Hz frames are highly correlated and can otherwise make validation results unrealistically optimistic.

Depth values are assumed to be in meters. `orientation_rpy` is `[roll, pitch, yaw]` in radians, and `angular_velocity` is `[wx, wy, wz]` in radians per second.

## 1. Construct the model

```python
from depth_terrain_classifier import DepthTerrainClassifier

model = DepthTerrainClassifier(
    pca_dim=8,
    num_prototypes=2,           # Configurable multiple prototypes per class
    metric_type="euclidean",   # Also: "diag_mahalanobis", "full_mahalanobis"
    temperature=1.0,
    temporal_alpha=0.45,
    switch_frames=2,
    device="cpu",
)
```

With two prototypes, each terrain can represent two common appearance modes, such as different viewing distances or approach directions. The number is automatically limited by the available samples in each class.

## 2. Optional flat-ground calibration

Use unlabeled flat-ground frames spanning normal roll and pitch variation:

```python
# flat_depth: [N_flat, H, W]
# flat_rpy:   [N_flat, 3]
model.fit_reference_model(flat_depth, flat_rpy)
```

The fitted model stores only three small reference images: an intercept, roll sensitivity, and pitch sensitivity.

## 3. Initial fit with rough terrain and stairs

```python
import torch

# Concatenate the initial terrain data.
initial_depth = torch.cat([rough_depth, stairs_depth], dim=0)
initial_rpy = torch.cat([rough_rpy, stairs_rpy], dim=0)
initial_omega = torch.cat([rough_omega, stairs_omega], dim=0)
initial_labels = (
    ["rough"] * len(rough_depth)
    + ["stairs"] * len(stairs_depth)
)

model.fit_initial(
    initial_depth,
    initial_labels,
    orientation_rpy=initial_rpy,
    angular_velocity=initial_omega,
)
```

This fits the feature standardization, PCA transform, and class prototypes.

## 4. Deployment inference

```python
prediction = model.predict_depth(
    current_depth,                 # [H, W]
    orientation_rpy=current_rpy,   # [3]
    angular_velocity=current_omega,# [3]
    temporal=True,
)

print(prediction.label)                  # Temporally filtered output
print(prediction.instantaneous_label)    # Current-frame output
print(dict(zip(prediction.labels, prediction.probabilities.tolist())))
```

Reset temporal state after an episode reset, camera discontinuity, or a long sensing interruption:

```python
model.reset_temporal_filter()
```

## 5. Add PIT and GAP between evaluations

PCA stays frozen by default. Only the new class features are projected and clustered, so existing classes are not retrained.

```python
model.add_class(
    "pit",
    pit_depth,
    orientation_rpy=pit_rpy,
    angular_velocity=pit_omega,
    num_prototypes=2,
    refit_pca=False,
)

model.add_class(
    "gap",
    gap_depth,
    orientation_rpy=gap_rpy,
    angular_velocity=gap_omega,
    num_prototypes=2,
    refit_pca=False,
)
```

Additional labeled data for an existing class can be appended and only that class is reclustered:

```python
model.update_class(
    "rough",
    more_rough_depth,
    orientation_rpy=more_rough_rpy,
    angular_velocity=more_rough_omega,
)
```

The classifier retains engineered feature vectors, not raw depth images. Therefore, an exact PCA refit remains inexpensive if later diagnostics show that the original rough/stairs PCA subspace does not represent PIT/GAP well:

```python
errors = model.classifier.pca_reconstruction_error(new_class_features)
print(errors.mean())

model.classifier.refit_pca_from_stored_features(pca_dim=10)
```

## 6. Hyperparameter selection

Extract features once and run stratified cross-validation:

```python
features = model.extract_features(all_depth, all_rpy, all_omega)

results = DepthTerrainClassifier.cross_validate_hyperparameters(
    features,
    all_labels,
    param_grid={
        "pca_dim": [4, 6, 8, 10],
        "num_prototypes": [1, 2, 3],
        "metric_type": ["euclidean", "diag_mahalanobis"],
        "metric_regularization": [1e-3, 1e-2],
        "temperature": [0.5, 1.0, 2.0],
        "whiten": [True, False],
    },
    n_splits=5,
    scoring="balanced_accuracy",
)

print(results[0])
```

The convenience method below performs feature extraction first:

```python
results = model.run_hyperparameter_search(
    all_depth,
    all_labels,
    orientation_rpy=all_rpy,
    angular_velocity=all_omega,
    n_splits=5,
)
```

For temporal filtering, use an ordered validation set and an episode or traversal ID per frame:

```python
validation_features = model.extract_features(val_depth, val_rpy, val_omega)

temporal_results = model.search_temporal_hyperparameters(
    validation_features,
    val_labels,
    sequence_ids=val_episode_ids,
    alphas=[0.25, 0.45, 0.65, 1.0],
    switch_frames=[1, 2, 3],
)

print(temporal_results[0])
```

## 7. Save and load

```python
model.save("terrain_classifier.pt")

# Construct a model with the same extractor configuration before loading.
restored = DepthTerrainClassifier(
    pca_dim=8,
    num_prototypes=2,
)
restored.load("terrain_classifier.pt")
```

## Parameters most likely to require camera-specific tuning

- `crop`: exclude robot body/legs and irrelevant image regions.
- `min_depth`, `max_depth`: match the sensor's reliable range.
- `far_depth`: choose a value representing open space or distant gap returns.
- `close_depth`: choose a value appropriate for overhead/front obstacles.
- `sobel_edge_threshold`: set above ordinary depth noise but below meaningful ledges.
- `output_size`: `32x48` is a good starting point; larger images increase cost and may amplify noise.

## Incremental-learning recommendation

Begin with a frozen PCA transform when adding PIT and GAP. Compare their PCA reconstruction errors with the initial rough/stairs distribution. Refit PCA only when the new-class reconstruction error or validation performance indicates that the original subspace is inadequate. This preserves the inexpensive class-addition workflow while still allowing a controlled representation refresh between evaluations.
