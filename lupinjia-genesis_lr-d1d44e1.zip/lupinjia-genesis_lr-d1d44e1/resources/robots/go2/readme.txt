hf means high fidelity
